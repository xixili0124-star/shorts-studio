# 예시 영상 출처

기존 서울 사진 3장과 합성 배경음악·예시 자막/그래픽은 기본 프로젝트에서 제거했습니다. 새 예시는 실제 촬영 영상 세 편이며, 정지 사진에 움직임을 합성한 파일이 아닙니다. 원본 촬영자의 CC0 공개 고지를 확인했습니다(2026-09-06).

| 파일 | 촬영자·원본 | 발췌 구간 | 이용 조건 |
| --- | --- | --- | --- |
| `public/demo/portrait.mp4` | [Msahique / Raw Video.webm](https://commons.wikimedia.org/wiki/File:Raw_Video.webm) | 3–15초 | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `public/demo/cat-walking.mp4` | [Dzkouslavia / Black Cat walking.webm](https://commons.wikimedia.org/wiki/File:Black_Cat_walking.webm) | 0–10초 | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `public/demo/waves.mp4` | [Rhetos / Salzwiesenwellen (Horumersiel).webm](https://commons.wikimedia.org/wiki/File:Salzwiesenwellen_(Horumersiel).webm) | 2–12초 | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |

H.264/AAC MP4로 변환하고 해상도를 낮췄으며 원본 녹음 소리를 유지했습니다. [예시 매니페스트](public/demo/manifest.json)에 다운로드 원본, 발췌 구간, 해상도·길이·용량 및 SHA-256을 기록했습니다. 인물이 이 제품을 추천한다는 뜻은 아니며, 예시 영상은 편집 기능을 시험하기 위한 것입니다. 한국어 자동자막 품질 평가는 별도 한국어 영상으로 진행해야 합니다.

`public/og.png`는 이 실험판을 위해 생성한 AI 이미지입니다. 앱의 실제 스크린샷이 아닙니다.

## 한국어·영문 폰트 64종

한국어 37종과 영문 27종입니다. Google Fonts 공식 저장소의 고정 revision `ade3d1533e06b2b1462ffcde8e08b129627ca360`에서 각 `OFL.txt`와 `METADATA.pb`를 읽어 이름·지원 문자·선택 굵기를 확인했습니다(2026-08-28). [검증한 메타데이터·해시 목록](public/licenses/google-fonts/catalog-sources.json)에 원본 URL을 기록하고, 폰트별 OFL 고지와 메타데이터를 함께 보관합니다.

글꼴로 제작한 상업 영상은 OFL로 배포할 의무가 없습니다. 폰트 바이너리는 수정하거나 번들에 포함하지 않고 Google Fonts CSS를 불러옵니다. 나중에 폰트를 직접 호스팅하거나 번들에 포함할 경우 해당 저작권·라이선스 고지를 함께 보존해야 합니다. [Google Fonts 공식 FAQ](https://developers.google.com/fonts/faq), [OFL 공식 FAQ](https://openfontlicense.org/ofl-faq/)

| 이름 | Google Fonts family | 표시 굵기 | 문자 | 이용 조건 |
| --- | --- | --- | --- | --- |
| 본고딕 | Noto Sans KR | 900 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/notosanskr/OFL.txt) |
| 나눔고딕 | Nanum Gothic | 800 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/nanumgothic/OFL.txt) |
| 고딕 A1 | Gothic A1 | 900 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gothica1/OFL.txt) |
| IBM 플렉스 | IBM Plex Sans KR | 600 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/ibmplexsanskr/OFL.txt) |
| 고운돋움 | Gowun Dodum | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gowundodum/OFL.txt) |
| 오르빗 | Orbit | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/orbit/OFL.txt) |
| 나눔고딕 코딩 | Nanum Gothic Coding | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/nanumgothiccoding/OFL.txt) |
| 본명조 | Noto Serif KR | 900 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/notoserifkr/OFL.txt) |
| 나눔명조 | Nanum Myeongjo | 800 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/nanummyeongjo/OFL.txt) |
| 고운바탕 | Gowun Batang | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gowunbatang/OFL.txt) |
| 햄릿 | Hahmlet | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/hahmlet/OFL.txt) |
| 송명 | Song Myung | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/songmyung/OFL.txt) |
| 산하엽 | Diphylleia | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/diphylleia/OFL.txt) |
| 검은고딕 | Black Han Sans | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/blackhansans/OFL.txt) |
| 도현 | Do Hyeon | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/dohyeon/OFL.txt) |
| 주아 | Jua | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/jua/OFL.txt) |
| 구기 | Gugi | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gugi/OFL.txt) |
| 해바라기 | Sunflower | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/sunflower/OFL.txt) |
| 동글 | Dongle | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/dongle/OFL.txt) |
| 베이글 팻 | Bagel Fat One | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/bagelfatone/OFL.txt) |
| 개구 | Gaegu | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gaegu/OFL.txt) |
| 감자꽃 | Gamja Flower | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gamjaflower/OFL.txt) |
| 하이멜로디 | Hi Melody | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/himelody/OFL.txt) |
| 싱글데이 | Single Day | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/singleday/OFL.txt) |
| 나눔손글씨 펜 | Nanum Pen Script | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/nanumpenscript/OFL.txt) |
| 나눔손글씨 붓 | Nanum Brush Script | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/nanumbrushscript/OFL.txt) |
| 연성 | Yeon Sung | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/yeonsung/OFL.txt) |
| 기랑해랑 | Kirang Haerang | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/kiranghaerang/OFL.txt) |
| 동해독도 | East Sea Dokdo | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/eastseadokdo/OFL.txt) |
| 흑백사진 | Black And White Picture | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/blackandwhitepicture/OFL.txt) |
| 42dot 산스 | 42dot Sans | 700 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/42dotsans/OFL.txt) |
| 큐트 | Cute Font | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/cutefont/OFL.txt) |
| 독도 | Dokdo | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/dokdo/OFL.txt) |
| 가석체 | Gasoek One | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/gasoekone/OFL.txt) |
| 모이라이 | Moirai One | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/moiraione/OFL.txt) |
| 푸어 스토리 | Poor Story | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/poorstory/OFL.txt) |
| 스타일리시 | Stylish | 400 | 한국어 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/stylish/OFL.txt) |
| Inter | Inter | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/inter/OFL.txt) |
| Montserrat | Montserrat | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/montserrat/OFL.txt) |
| Poppins | Poppins | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/poppins/OFL.txt) |
| Roboto | Roboto | 900 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/roboto/OFL.txt) |
| Open Sans | Open Sans | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/opensans/OFL.txt) |
| Lato | Lato | 900 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/lato/OFL.txt) |
| Oswald | Oswald | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/oswald/OFL.txt) |
| Bebas Neue | Bebas Neue | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/bebasneue/OFL.txt) |
| Anton | Anton | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/anton/OFL.txt) |
| Archivo Black | Archivo Black | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/archivoblack/OFL.txt) |
| Barlow Condensed | Barlow Condensed | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/barlowcondensed/OFL.txt) |
| League Spartan | League Spartan | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/leaguespartan/OFL.txt) |
| Outfit | Outfit | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/outfit/OFL.txt) |
| Manrope | Manrope | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/manrope/OFL.txt) |
| Space Grotesk | Space Grotesk | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/spacegrotesk/OFL.txt) |
| Playfair Display | Playfair Display | 800 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/playfairdisplay/OFL.txt) |
| Lora | Lora | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/lora/OFL.txt) |
| DM Serif Display | DM Serif Display | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/dmserifdisplay/OFL.txt) |
| Libre Baskerville | Libre Baskerville | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/librebaskerville/OFL.txt) |
| Merriweather | Merriweather | 900 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/merriweather/OFL.txt) |
| Abril Fatface | Abril Fatface | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/abrilfatface/OFL.txt) |
| Lobster | Lobster | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/lobster/OFL.txt) |
| Pacifico | Pacifico | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/pacifico/OFL.txt) |
| Caveat | Caveat | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/caveat/OFL.txt) |
| JetBrains Mono | JetBrains Mono | 700 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/jetbrainsmono/OFL.txt) |
| Bungee | Bungee | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/bungee/OFL.txt) |
| Press Start 2P | Press Start 2P | 400 | 영문 | [OFL 1.1](https://raw.githubusercontent.com/google/fonts/ade3d1533e06b2b1462ffcde8e08b129627ca360/ofl/pressstart2p/OFL.txt) |

영문 전용 글꼴은 한국어 글리프를 제공하지 않으므로 한국어 문구에는 기기의 대체 글꼴이 표시될 수 있습니다. 목록의 영문 미리보기에는 각 글꼴 이름을 사용합니다. 글꼴 요청에는 선택한 family와 weight만 들어가며, 사용자 자막·원고를 Google Fonts URL의 text 파라미터에 넣지 않습니다. 처음 글꼴을 불러올 때는 인터넷 연결이 필요합니다.

## 사용자 등록 효과음 37종

기존 Kenney·OpenGameArt 효과음 24종은 기본 라이브러리와 배포 파일에서 제거했습니다. 현재 라이브러리는 사용자가 직접 제공한 MP3 37개만 정적 파일로 읽으며, 실행 중 음원을 합성하거나 외부 API를 호출하지 않습니다. 원본 음질과 길이는 바꾸지 않고 웹 경로에 안전한 영문 파일명만 적용했습니다.

이 파일들에는 재배포 또는 상업적 사용을 허용한다는 라이선스 자료가 함께 제공되지 않았습니다. 특히 배달의민족·배그·리그 오브 레전드·GTA·드래곤볼 등 브랜드나 저작물이 연상되는 음원은 공개 서비스와 유료 영상에 포함하기 전에 권리자 허락 또는 해당 음원의 명확한 이용 조건을 확인해야 합니다. 현재 파일을 CC0나 무료 상업용 음원으로 표시하지 않습니다.

클릭·촬영 / 알림·완료 / 오류·의문 / 등장·상승 / 타격·폭발 / 코믹·리액션 / 드럼·긴장 / 게임·무기 / 금전으로 나눕니다. 분류 변경은 원본 파일과 이용 권리를 바꾸지 않습니다.

[효과음 매니페스트](public/sounds/manifest.json)에 편집기 ID, 원래 파일명, 재생시간, 용량, SHA-256을 기록했습니다. 기존 프로젝트에 이미 저장된 예전 효과음 파일은 변경하지 않습니다. 새 기본 효과음은 자막 인식에 포함하는 음성이 아니라 효과음 트랙으로 취급합니다.

## Myinstants 외부 탐색

사용자가 제공한 [Myinstants app 페이지](https://www.myinstants.com/ko/instant/app/)는 외부 탐색 링크입니다. 사이트의 음원을 저장소에 포함하거나 자동 수집하지 않습니다. 다운로드·임베드 기능이 있다고 상업 영상 재사용 허락까지 확인된 것은 아니므로, 가져오는 음원은 이용자가 별도 권리를 확인해야 합니다. [이용약관](https://www.myinstants.com/ko/terms_of_use.html), [저작권 정책](https://www.myinstants.com/ko/dcma_copyright_policy.html)

## 플랫폼 안전영역 · 1080×1920 참고값

| 프리셋 | 위 / 오른쪽 / 아래 / 왼쪽 | 근거 |
| --- | --- | --- |
| YouTube Shorts | 192 / 108 / 480 / 65 px | Google 공식 광고 가이드의 위10%·아래25%·오른쪽10%, 왼쪽은 자체 편집 여유 |
| Instagram Reels | 270 / 230 / 672 / 65 px | Meta 2023 템플릿의 꺾인 우하단을 보수적인 사각형으로 환산 |
| TikTok | 252 / 240 / 640 / 120 px | Creative Center 세로 LTR 도해를 보수적인 사각형으로 환산 |
| 세 플랫폼 공통 | 270 / 240 / 672 / 120 px | 위 세 사각형의 교집합, 자체 추천 |

[Google Shorts Ads 가이드](https://business.google.com/us/ad-solutions/youtube-ads/shorts-ads/), [Meta Safe Zone Checker 원본 PPT](https://www.facebook.com/gms_hub/share/safe-zone-checker-2023-08-24.pptx), [TikTok Creative Accelerator](https://ads.tiktok.com/business/creativecenter/quicktok/online/tiktok_creative_accelerator/pc/en), [TikTok 현재 광고 사양](https://ads.tiktok.com/resources/help/article/tiktok-auction-in-feed-ads?lang=en-GB)

Meta 자료는 표지에 Last Updated June 15th, 2023으로 표시된 구형 참고 자료입니다. TikTok 교육 도해의 버전 날짜는 확인되지 않았습니다. 위 값은 최신 공식 공통 규격이 아니며, 일반 게시물·광고·기기·설명 길이·추가 버튼에 따라 달라집니다. 편집기에서 각 여백을 조절할 수 있고 가이드는 출력 영상에 포함되지 않습니다.

## 브라우저 AI 엔진·모델

| 구성 | 고정 버전 / 원본 | 이용 조건 |
| --- | --- | --- |
| Supertonic 2 한국어 TTS 모델 | [Supertone/supertonic-2](https://huggingface.co/Supertone/supertonic-2), revision `75e6727618a02f323c720cba9478152d4bc16ca4` | OpenRAIL-M, [동봉 원문](public/vendor/supertonic/MODEL-LICENSE) |
| Supertonic 공식 JavaScript helper | [공식 소스 e71c5167](https://github.com/supertone-inc/supertonic/blob/e71c51671494c9dd15167fc464985f4e2099605d/web/helper.js) | MIT, [동봉 원문](public/vendor/supertonic/LICENSE) |
| Whisper Tiny 다국어 ONNX 모델 | [Xenova/whisper-tiny](https://huggingface.co/Xenova/whisper-tiny), revision `5332fcc35e32a33b86612b9a57a89be7906102b1` | 모델 카드 표기 Apache-2.0 |
| Transformers.js | [공식 v3.8.1](https://github.com/huggingface/transformers.js/tree/3.8.1) | Apache-2.0, [동봉 원문](public/vendor/transformers/3.8.1/LICENSE) |
| 번들 Jinja 템플릿 엔진 | @huggingface/jinja 0.5.3 | MIT, [동봉 원문](public/vendor/transformers/3.8.1/LICENSE-JINJA) |
| Transformers.js 내부 ONNX Runtime·WASM | 1.22.0-dev.20250409-89f8206ba4 | [MIT 원문](public/vendor/transformers/3.8.1/LICENSE-ONNXRUNTIME), [제3자 고지](public/vendor/transformers/3.8.1/THIRD-PARTY-NOTICES-ONNXRUNTIME.txt) |
| ONNX Runtime Web | [Microsoft v1.23.2](https://github.com/microsoft/onnxruntime/tree/v1.23.2), TTS 전용 | [MIT 원문](public/vendor/onnxruntime-web/1.23.2/LICENSE), [제3자 고지](public/vendor/onnxruntime-web/1.23.2/ThirdPartyNotices.txt) |

모델 가중치는 Git이나 ZIP에 넣지 않습니다. 사용자가 실행한 뒤 해당 고정 revision의 공개 파일을 받습니다. 실행 엔진은 vendor 폴더에 포함하며, 출처·크기·SHA-256은 [browser-ai-vendors.json](public/vendor/browser-ai-vendors.json)에 기록했습니다. Supertonic helper는 npm import를 고정 로컬 ORT import로 바꾸었고 파일 상단에 변경을 표시했습니다. mediabunny 원본 vendor 파일은 변경하지 않았습니다.

**Supertonic 모델과 예제 코드의 라이선스는 서로 다릅니다.** 모델의 이용 제한을 따르고, 생성 음성을 게시할 때 AI 생성물임을 명시해야 합니다. 앱은 다운로드 전 모델 조건 링크와 동의란, 결과 확인 화면의 고지를 제공합니다. 브라우저 기본 모드에는 특정 인물의 음성 복제가 없으며, 아래의 PC 확장은 별도 모델을 사용합니다.

설치된 기기 음성은 [Web Speech API](https://webaudio.github.io/web-speech-api/)의 `localService` 보이스만 사용합니다. 파일을 반환하지 않는 재생 전용 API이므로 WAV 생성과 구분했습니다. 운영체제에 설치된 보이스 자체의 사용 조건은 해당 제공자의 조건을 확인하세요.

## 선택형 PC 자동자막 엔진 · Whisper large-v3-turbo

브라우저 Tiny와 별도로 사용하는 PC 인식 환경입니다. 모델·Python·CUDA 런타임은 저장소나 배포 ZIP에 넣지 않고, 사용자가 `setup-pc-asr.cmd`의 다운로드에 동의하면 별도 환경에 준비합니다. Vox·GPT-SoVITS의 Python 환경에 설치하지 않습니다.

| 구성 | 고정 버전 / 원본 | 이용 조건 |
| --- | --- | --- |
| Whisper large-v3-turbo CTranslate2 모델 | [dropbox-dash 고정 revision 0a363e91](https://huggingface.co/dropbox-dash/faster-whisper-large-v3-turbo/tree/0a363e9161cbc7ed1431c9597a8ceaf0c4f78fcf), 원본은 OpenAI Whisper large-v3-turbo | 고정 모델 카드의 `license: mit` 표기. [원본 Whisper MIT 고지 · v20250625](https://github.com/openai/whisper/blob/v20250625/LICENSE)도 함께 확인 |
| faster-whisper | [SYSTRAN v1.2.1](https://github.com/SYSTRAN/faster-whisper/tree/v1.2.1) | [MIT 원문](https://github.com/SYSTRAN/faster-whisper/blob/v1.2.1/LICENSE), SYSTRAN 저작권 고지 |
| CTranslate2 | [OpenNMT v4.8.1](https://github.com/OpenNMT/CTranslate2/tree/v4.8.1) | [MIT 원문](https://github.com/OpenNMT/CTranslate2/blob/v4.8.1/LICENSE), SYSTRAN·OpenNMT 저작권 고지 |
| GPU 실행 라이브러리 | cuBLAS 12.8.4.1, CUDA runtime 12.8.90. `setup_pc_asr.py`의 고정 Windows wheel 사용 | 각 NVIDIA 패키지의 별도 제공 조건·고지를 유지. 위 모델·추론 코드의 MIT로 묶지 않음 |

모델 파일의 크기·SHA-256·revision은 `pc_asr_worker.py`, Python 패키지 버전은 `pc-asr-requirements.txt`, CUDA wheel의 URL·크기·SHA-256은 `setup_pc_asr.py`에 기록합니다. 다운로드한 모델 카드도 해시를 확인해 유지합니다. PyAV·ONNX Runtime 등 다른 실행 의존성의 라이선스·제3자 고지는 각 설치 패키지에 따르며 전체 환경을 하나의 MIT 라이선스로 간주하지 않습니다.

모델 카드는 저장된 가중치를 FP16으로 설명하지만 앱의 기본 GPU 계산 형식은 `int8_float16`입니다. CPU 설치를 명시 선택하면 `int8`를 사용합니다. 설치 시 장치와 실행 환경을 검사하며, 실제 인식 품질·처리 속도를 보장하는 표기는 아닙니다.

인식은 사용자가 실행한 뒤 같은 PC의 루프백 연결에서만 처리하며 오디오를 외부 모델 API로 보내지 않습니다. Whisper의 사용 조건은 사용자가 가져온 영상·음성의 권리를 대신하지 않습니다. 본인 또는 이용 권한이 있는 소재를 사용하세요.

## 선택형 PC 음성 엔진

모델·Python 런타임·참고 녹음은 이 저장소와 배포 ZIP에 포함하지 않습니다. 사용자가 Windows 설치 도구에서 동의하면 공식 저장소·PyPI·PyTorch 배포처에서 별도 다운로드합니다. 원문 라이선스는 내려받은 소스와 설치된 각 패키지에 유지합니다.

| 구성 | 출처·버전 | 이용 조건 |
| --- | --- | --- |
| VoxCPM 추론 코드 | [공식 2.0.3 / revision 19b6bf75](https://github.com/OpenBMB/VoxCPM/tree/19b6bf7590025418821a86dcb817504e0ad7e5df), [PyPI wheel](https://pypi.org/project/voxcpm/2.0.3/) | Apache-2.0, 설치 패키지의 라이선스 유지 |
| VoxCPM2 2B 모델·AudioVAE·tokenizer | [공식 모델 revision 32279eff](https://huggingface.co/openbmb/VoxCPM2/tree/32279effe8c19989596f05d353d1447f51d9e915) | [모델 카드 Apache-2.0](https://huggingface.co/openbmb/VoxCPM2/blob/32279effe8c19989596f05d353d1447f51d9e915/README.md) |
| GPT-SoVITS 소스 | [공식 revision 48b1a016](https://github.com/RVC-Boss/GPT-SoVITS/tree/48b1a0169a28582a8984402f82cf438d3bfa6aca) | [MIT](https://github.com/RVC-Boss/GPT-SoVITS/blob/48b1a0169a28582a8984402f82cf438d3bfa6aca/LICENSE) |
| v2ProPlus·s1v3·speaker embedding·BERT·HuBERT 자료 | [공식 배포 모델 revision 336b2ec4](https://huggingface.co/lj1995/GPT-SoVITS/tree/336b2ec4e8d4ac74740798dd40af44e74659ecaf) | 해당 저장소 [모델 카드의 MIT 표기](https://huggingface.co/lj1995/GPT-SoVITS/blob/336b2ec4e8d4ac74740798dd40af44e74659ecaf/README.md) |
| 한국어 형태소 분석 | [python-mecab-ko 1.3.7](https://pypi.org/project/python-mecab-ko/1.3.7/), [사전 2.1.1.post2](https://pypi.org/project/python-mecab-ko-dic/2.1.1.post2/) | 분석기 BSD-3-Clause / 사전 Apache-2.0 |
| 한국어 발음 변환 | [g2pk2 0.0.3](https://pypi.org/project/g2pk2/0.0.3/) | Apache-2.0 |
| Jieba 호환 처리 | [jieba 0.42.1](https://pypi.org/project/jieba/0.42.1/) | MIT |
| 언어 감지 모델 | Facebook fastText [lid.176.bin](https://fasttext.cc/docs/en/language-identification.html) | CC BY-SA 3.0. Joulin, Grave, Bojanowski, Mikolov의 [Bag of Tricks for Efficient Text Classification](https://arxiv.org/abs/1607.01759), Joulin 외 [FastText.zip](https://arxiv.org/abs/1612.03651) 기반 |
| 영어 발음 자료 | [NLTK 공식 리소스 목록](https://raw.githubusercontent.com/nltk/nltk_data/gh-pages/index.xml)의 CMUdict, averaged_perceptron_tagger, averaged_perceptron_tagger_eng | CMUdict의 동봉 고지, 두 태거의 MIT 고지 각각 유지 |
| PyTorch·torchaudio | [PyTorch 공식 배포](https://pytorch.org/), 2.5.1 | 패키지의 BSD 및 제3자 고지. CUDA 구성 요소는 별도 제공자 조건 |
| FFmpeg 실행 파일 | [imageio-ffmpeg 0.6.0](https://pypi.org/project/imageio-ffmpeg/0.6.0/)의 Windows FFmpeg 7.1 | Python 래퍼 BSD-2-Clause. 검증한 Windows 바이너리의 `-L` 고지는 GPL-3.0-or-later이며 제3자 고지도 별도 유지 |

Vox 모델·wheel의 고정 SHA-256은 `setup_vox_voice.py`, 추론 의존성은 `vox-voice-requirements.txt`에 기록합니다. 공식 wheel을 의존성 자동 설치 없이 넣고 필요한 추론 패키지만 설치합니다. Gradio·외부 ASR·denoiser·중국어/영어 전용 텍스트 정규화기는 사용하지 않습니다. 모델은 고정 revision에서 먼저 받고 런타임은 로컬 경로만 사용하며 원격 tokenizer 코드를 실행하지 않습니다.

GPT 모델 주요 파일 SHA-256은 `setup_pc_voice.py`, 발음 자료 SHA-256은 `prepare_pc_voice_resources.py`, Python 버전 고정은 `pc-voice-requirements.txt`와 `pc-voice-constraints.txt`에 기록합니다. 기존 PyTorch 채널과 별도로 코드·모델 버전을 고정하며, 전체 구성 요소를 하나의 MIT 라이선스로 간주하지 않습니다.

GPT의 Windows 호환을 위해 해당 엔진 프로세스에서만 `jieba_fast`를 Jieba로 연결하고 g2pk2의 MeCab 접근을 python-mecab-ko로 연결합니다. Vox는 이 발음 변환을 거치지 않습니다. 제3자 소스를 직접 수정하거나 eunjeon을 자동 설치하지 않습니다. 편집기의 검증 범위는 한국어 및 한국어·영어 혼용이며 개인 모델 학습은 제공하지 않습니다.

소스·모델의 이용 조건이 녹음자의 동의나 타인 사칭 허락을 대신하지 않습니다. 본인 또는 허락받은 녹음만 등록하도록 안내합니다. PC 모드의 AI 생성 표시 안내는 제품의 사용 원칙이며, MIT 라이선스 자체의 의무라고 주장하지 않습니다.

## 모자이크·크롭 추적

| 구성 | 출처·버전 | 이용 조건 |
| --- | --- | --- |
| PC SAM 2.1 Small | [Meta SAM 2 코드](https://github.com/facebookresearch/sam2/tree/2b90b9f5ceec907a1c18123530e92e794ad901a4), [공식 Small 모델](https://huggingface.co/facebook/sam2.1-hiera-small/tree/ee5bba1d82bb8749febdf90f45e84b687142ba03) | [Apache-2.0](https://github.com/facebookresearch/sam2/blob/2b90b9f5ceec907a1c18123530e92e794ad901a4/LICENSE), 설치 소스의 원문 유지 |
| 브라우저 MediaPipe Tasks Vision | [Google MediaPipe](https://github.com/google-ai-edge/mediapipe), npm @mediapipe/tasks-vision 1.0.1 | Apache-2.0, `public/vendor/mediapipe/1.0.1/LICENSE`와 파일별 SHA-256 manifest 동봉 |
| 얼굴 모자이크 BlazeFace full-range | [공식 float16 v1 파일](https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_full_range/float16/1/blaze_face_full_range.tflite), [모델 카드](https://storage.googleapis.com/mediapipe-assets/MediaPipe%20BlazeFace%20Model%20Card%20(Full%20Range).pdf) | Apache-2.0, Google MediaPipe 배포 모델 |
| 대상 크롭 EfficientDet-Lite2 | [공식 float32 v1 파일](https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite2/float32/1/efficientdet_lite2.tflite), [TensorFlow 모델 안내](https://www.kaggle.com/models/tensorflow/efficientdet/tensorFlow2/lite2-detection/1) | Apache-2.0, 검출 모델이 지원하는 대상 범주만 사용 |

브라우저 모델은 같은 사이트의 고정 파일에서 사용자의 첫 다운로드 동의 후 가져오며 영상은 브라우저 안에서 처리합니다. 모델 크기·SHA-256은 `browser-tracking-models.js`에 기록하고 캐시 재사용 때도 검증합니다. 같은 대상을 연결하는 시간축 처리는 이 프로젝트 코드입니다. 원래의 밝기 패턴 매칭 실행 경로는 제거했지만 이전 프로젝트에 저장된 좌표는 보존합니다.

PC 모델·Python 환경은 웹 배포와 설치용 앱 ZIP에 포함하지 않습니다. 사용자가 PC 설치를 실행할 때 공식 배포처에서 별도로 내려받습니다. SAM 소스 ZIP과 모델 해시·revision은 `setup_pc_tracking.py`와 `pc_tracking_worker.py`에 기록합니다. PyTorch·torchvision·PyAV와 CUDA 구성 요소의 별도 라이선스·제3자 고지는 각 설치 패키지에 유지하며 전체 환경을 Apache-2.0 하나로 간주하지 않습니다. 추적 결과는 사람의 검토가 필요하며, 모델 이용 조건은 영상에 포함된 인물의 동의나 소재 권리를 대신하지 않습니다.

PC 연결 설치기의 uv 실행 도구는 [Astral uv 0.12.7](https://github.com/astral-sh/uv/tree/0.12.7)의 공식 Windows wheel을 크기·SHA-256으로 확인합니다. uv의 MIT/Apache-2.0 및 함께 제공되는 고지는 설치 패키지에 유지합니다. 설치 파일은 관리자 권한이나 Windows 보안 설정 변경을 요청하지 않으며 로그인 시 자동 실행은 사용자가 선택한 경우에만 등록합니다.
